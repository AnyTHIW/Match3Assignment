using System.Collections.Generic;
using UnityEngine;

public class BoardCtrl : MonoBehaviour
{
    public static BoardCtrl Instance
    {
        get
        {
            return instance;
        }
        set
        {
            instance = value;
        }
    }
    private static BoardCtrl instance;


    public GameObject Board;
    
    private int spawnerNumber;

    private Vector2 cellsAreaOffset;
    private Vector2 cellsAreaSize;

    public GameObject CellReference;
    public GameObject[] SpawningPoint;
    public GameObject[,] grid;

    public void Awake()
    {
        Board = GameObject.FindWithTag("BOARD");

        cellsAreaOffset = Board.GetComponent<BoxCollider2D>().size;
        cellsAreaSize = Board.GetComponent<BoxCollider2D>().offset;
    }

    public void Start()
    {
        //CheckBoardInfo();

        //int cellNumberX = cellsAreaSize / cell;
        //int cellNumberY = cellsAreaSize / cellsAreaSize;
        //int width = (int)cellSize.x;
        //int heigth = (int)cellSize.y;
        //grid = new GameObject[width, heigth];

        //for (int x = 0; x < width; x++)
        //{
        //    for (int y = 0; y < heigth; y++)
            //{
            //    //grid[x, y] = Instantiate(tiles[Random.Range(0, tiles.Length)], new Vector3(x, y, 0), Quaternion.identity) as GameObject;
            //}
        //}

    }

    //private void MakeBoard()
    //{

    //}

    // �������� ����, ����, ������ ���� Ȯ��
    private void CheckBoardInfo()
    {
        spawnerNumber = GameObject.FindGameObjectsWithTag("SPAWNER").Length;
        CheckCellsAreaInfo();
        //InitBoard(cellsAreaInfo);
    }

    private void CheckCellsAreaInfo()
    {
        GameObject[] tmp;

        tmp = GameObject.FindGameObjectsWithTag("CELLSAREA");

        for (int i = 0; i < tmp.Length; i++)
        {
            //cellsAreaInfo.Add(tmp[i].GetComponent<BoxCollider2D>().size);
        }
    }

    private void InitBoard(List<Vector2> areaInfo)
    {
        foreach(Vector2 item in areaInfo)
        {
            //int VerticalRowNumber = (int)(item.x / cellSize.x);
            //int CellsNumberInVerticalRow = (int)(item.y / cellSize.y);

            //SweetsCtrl.instance
        }


    }

    //private Vector2 CalcCellsNumberInCellsArea(Vector2 size)
    //{
    //    //Vector2 cellCount = new Vector2 ((int)(size.x / cellSize.x), (int)(size.y / cellSize.y));
    //    //return cellCount;
    //}

    private void FillEmptyCell()
    {
        // ��ĭ ��������, �����ʿ��� ��ĭ ä���
    }

}
